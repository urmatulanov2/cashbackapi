package kg.nurtelecom.cashbackapi.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.Size;
import java.io.File;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class OrganizationModel {
    private Long id;
    @Size(max = 255)
    private String imageUrl;
    private Boolean status;
    @Size(min = 5, max = 255)
    private String name;
    private Long categoryId;
    private String categoryName;
    @Size(min = 50, max = 255)
    private String description;
}