package kg.nurtelecom.cashbackapi;

public @interface Autowired {
}
