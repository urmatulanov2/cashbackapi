package kg.nurtelecom.cashbackapi.service;

import kg.nurtelecom.cashbackapi.entity.Organization;
import kg.nurtelecom.cashbackapi.model.OrganizationModel;
import kg.nurtelecom.cashbackapi.model.OrganizationModelImage;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface OrganizationService {
    Organization findById(Long id);

    List<Organization> findAll();

    Page<OrganizationModel> findAll(Pageable pageable);

    Page<OrganizationModel> findAllByNameOrDescription(String search, Pageable pageable);

    Organization create(OrganizationModelImage organization);

    String deleteById(Long id);

    Organization putById(Long id, OrganizationModelImage organization);

    List<OrganizationModel> findAllOrganizationList();

    List<OrganizationModel> getOrganizationListByClientId(Long id);

    OrganizationModel getOrganizationById(Long id);
}
