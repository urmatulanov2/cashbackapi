package kg.nurtelecom.cashbackapi.service;

import kg.nurtelecom.cashbackapi.entity.Event;
import kg.nurtelecom.cashbackapi.model.EventFullModel;
import kg.nurtelecom.cashbackapi.model.EventModel;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface EventService {
    Event findById(Long id);

    List<Event> findAll();

    Event create(Event event);

    String deleteById(Long id);

    Event putById(Long id, Event event);

    List<EventModel> findAllEventsByOrgId(@Param("id") Long id);

    List<EventFullModel> getAllEventsByOrgId(@Param("id") Long id);

    Page<EventModel> findAllEventsByOrgIdAndName(Long id, String search, Pageable pageable);

    Page<EventModel> findAllEventsByOrgIdWithPagination(Long id, Pageable pageable);

}
