package kg.nurtelecom.cashbackapi.service;

import kg.nurtelecom.cashbackapi.entity.BalanceHistory;
import kg.nurtelecom.cashbackapi.model.HistoryModel;

import java.util.List;

public interface BalanceHistoryService {
    BalanceHistory findById(Long id);

    List<BalanceHistory> findAll();

    BalanceHistory create(BalanceHistory BalanceHistory);

    String deleteById(Long id);

    BalanceHistory putById(Long id, BalanceHistory BalanceHistory);

    List<HistoryModel> findHistoryByClientId(Long id);

    List<HistoryModel> findHistoryByClientAndOrgAndBonusTypeId(Long clientId, Long orgId, Long typeId);

    List<HistoryModel> findBalanceByClientAndOrgAndBonusTypeId(Long clientId, Long orgId, Long typeId);
}
