package kg.nurtelecom.cashbackapi.service.impl;

import kg.nurtelecom.cashbackapi.dao.BalanceDao;
import kg.nurtelecom.cashbackapi.entity.BalanceHistory;
import kg.nurtelecom.cashbackapi.model.HistoryModel;
import kg.nurtelecom.cashbackapi.repository.BalanceHistoryRepository;
import kg.nurtelecom.cashbackapi.service.BalanceHistoryService;
import kg.nurtelecom.cashbackapi.utils.RecordNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BalanceHistoryServiceImpl implements BalanceHistoryService {
    @Autowired
    private BalanceHistoryRepository balanceHistoryRepository;

    @Autowired
    private BalanceDao balanceDao;

    public BalanceHistory findById(Long id) {
        return balanceHistoryRepository.findById(id).orElseThrow(() ->
                new RecordNotFoundException("Record not found with id:" + id));
    }
    public List<HistoryModel> findHistoryByClientId(Long id) {
        return balanceDao.getBalanceHistoryByClientId(id);
    }

    @Override
    public List<HistoryModel> findHistoryByClientAndOrgAndBonusTypeId(Long clientId, Long orgId, Long typeId) {
        return balanceDao.getBalanceHistoryByClientIdAndOrgIdAndBonusTypeId(clientId, orgId, typeId);
    }

    @Override
    public List<HistoryModel> findBalanceByClientAndOrgAndBonusTypeId(Long clientId, Long orgId, Long typeId) {
        return balanceDao.getBalanceByClientIdAndOrgIdAndBonusTypeId(clientId, orgId, typeId);
    }

    public List<BalanceHistory> findAll() {
        return balanceHistoryRepository.findAll();
    }

    public BalanceHistory create(BalanceHistory balanceHistory) {
        return balanceHistoryRepository.save(balanceHistory);
    }

    public String deleteById(Long id) {
        balanceHistoryRepository.deleteById(id);
        return "BalanceHistory number " + id + " has been deleted!";
    }

    public BalanceHistory putById(Long id, BalanceHistory balanceHistory) {
        return balanceHistoryRepository.findById(id)
                .map(newBalanceHistory -> {
                    newBalanceHistory.setAmount(balanceHistory.getAmount());
                    newBalanceHistory.setBalance(balanceHistory.getBalance());
                    newBalanceHistory.setOperationType(balanceHistory.getOperationType());
                    return balanceHistoryRepository.save(newBalanceHistory);
                })
                .orElseThrow(() ->
                        new RecordNotFoundException("Record not found with id:" + id));
    }


}
