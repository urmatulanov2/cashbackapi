package kg.nurtelecom.cashbackapi.service.impl;

import kg.nurtelecom.cashbackapi.apicontroller.OrgCategoryRestController;
import kg.nurtelecom.cashbackapi.dao.OrganizationDao;
import kg.nurtelecom.cashbackapi.entity.Organization;
import kg.nurtelecom.cashbackapi.model.OrganizationModel;
import kg.nurtelecom.cashbackapi.model.OrganizationModelImage;
import kg.nurtelecom.cashbackapi.repository.OrganizationRepository;
import kg.nurtelecom.cashbackapi.service.OrganizationService;
import kg.nurtelecom.cashbackapi.utils.ImageManager;
import kg.nurtelecom.cashbackapi.utils.RecordNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.List;

@Service
public class OrganizationServiceImpl implements OrganizationService {
    @Autowired
    private OrganizationRepository organizationRepository;

    @Autowired
    private OrganizationDao organizationDao;

    @Autowired
    private OrgCategoryRestController orgCategoryRestController;


    public Organization findById(Long id) {
        return organizationRepository.findById(id).orElseThrow(() ->
                new RecordNotFoundException("Record not found with id:" + id));
    }

    public List<Organization> findAll() {
        return organizationRepository.findAll();
    }

    @Override
    public Page<OrganizationModel> findAll(Pageable pageable) {
        return organizationRepository.findAllOrganizationListWithPagination(pageable);
    }

    @Override
    public Page<OrganizationModel> findAllByNameOrDescription(String search, Pageable pageable) {
        return organizationRepository.findAllByNameOrDescription(search, pageable);
    }

    public Organization create(OrganizationModelImage organizationModelImage) {
        String imagePathDB = null;
        if(!organizationModelImage.getImg().isEmpty()){
            imagePathDB = ImageManager.uploadImage(organizationModelImage.getImg());
        }
        Organization organization = new Organization();
        organization.setName(organizationModelImage.getName());
        organization.setStatus(organizationModelImage.getStatus());
        organization.setImageUrl(imagePathDB);
        organization.setOrgCategory(orgCategoryRestController.getOrgCategoryById(organizationModelImage.getCategoryId()));
        organization.setDescription(organizationModelImage.getDescription());
        return organizationRepository.save(organization);
    }

    public String deleteById(Long id) {
        OrganizationModel organization = getOrganizationById(id);
        ImageManager.deleteImage(organization.getImageUrl());
        organizationRepository.deleteById(id);
        return "Organization number " + id + " has been deleted!";
    }

    public Organization putById(Long id, OrganizationModelImage organizationModelImage) {
        String imagePath = null;
        if(!organizationModelImage.getImg().isEmpty()){
            Organization organization = findById(id);
            String deleteFilePath = organization.getImageUrl();
            ImageManager.deleteImage(deleteFilePath);
            imagePath = ImageManager.uploadImage(organizationModelImage.getImg());
        }
        final String newImagePath = imagePath;

        return organizationRepository.findById(id)
                .map(newOrganization -> {
                    newOrganization.setDescription(organizationModelImage.getDescription());
                    newOrganization.setName(organizationModelImage.getName());
//                    newOrganization.setClients(organization.getClients());
                    if (newImagePath != null) {
                        newOrganization.setImageUrl(newImagePath);
                    }
                    newOrganization.setStatus(organizationModelImage.getStatus());
                    Long catId = organizationModelImage.getCategoryId();
                    if (catId != null) {
                        newOrganization.setOrgCategory(orgCategoryRestController.getOrgCategoryById(organizationModelImage.getCategoryId()));
                    }
                    return organizationRepository.save(newOrganization);
                })
                .orElseThrow(() ->
                        new RecordNotFoundException("Record not found with id:" + id));
    }
//    public Organization putById(Long id, Organization organization) {
//        return organizationRepository.findById(id)
//                .map(newOrganization -> {
//                    newOrganization.setDescription(organization.getDesription());
//                    newOrganization.setName(organization.getName());
//                    newOrganization.setClients(organization.getClients());
//                    newOrganization.setStatus(organization.getStatus());
//                    newOrganization.setImageUrl(organization.getImage());
//                    newOrganization.setOrgCategory(organization.getOrgCategory());
//                    return organizationRepository.save(newOrganization);
//                })
//                .orElseThrow(() ->
//                        new RecordNotFoundException("Record not found with id:" + id));
//    }


    public List<OrganizationModel> findAllOrganizationList() {
        return organizationRepository.findAllOrganizationList();
    }

    public List<OrganizationModel> getOrganizationListByClientId(Long id) {
        return organizationDao.getOrgByClientId(id);
    }

    public OrganizationModel getOrganizationById(Long id) {
        return organizationRepository.getOrganizationById(id);
    }
}
