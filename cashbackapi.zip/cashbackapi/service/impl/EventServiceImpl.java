package kg.nurtelecom.cashbackapi.service.impl;

import kg.nurtelecom.cashbackapi.dao.EventDao;
import kg.nurtelecom.cashbackapi.entity.Event;
import kg.nurtelecom.cashbackapi.model.EventFullModel;
import kg.nurtelecom.cashbackapi.model.EventModel;
import kg.nurtelecom.cashbackapi.repository.EventRepository;
import kg.nurtelecom.cashbackapi.service.EventService;
import kg.nurtelecom.cashbackapi.utils.RecordNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EventServiceImpl implements EventService {
    @Autowired
    private EventRepository eventRepository;

    @Autowired
    private EventDao eventDao;

    public Event findById(Long id) {
        return eventRepository.findById(id).orElseThrow(() ->
                new RecordNotFoundException("Record not found with id:" + id));
    }

    public List<Event> findAll() {
        return eventRepository.findAll();
    }

    public Event create(Event event) {
        return eventRepository.save(event);
    }

    public String deleteById(Long id) {
        eventRepository.deleteById(id);
        return "Event number " + id + " has been deleted!";
    }

    public Event putById(Long id, Event event) {
        return eventRepository.findById(id)
                .map(newEvent -> {
                    newEvent.setName(event.getName());
                    newEvent.setDescription(event.getDescription());
                    newEvent.setDateTo(event.getDateTo());
                    newEvent.setDateFrom(event.getDateFrom());
                    newEvent.setOrganization(event.getOrganization());
                    return eventRepository.save(newEvent);
                })
                .orElseThrow(() ->
                        new RecordNotFoundException("Record not found with id:" + id));
    }

    public List<EventModel> findAllEventsByOrgId(@Param("id") Long id) {
        return eventRepository.findAllEventsByOrgId(id);
    }

    public List<EventFullModel> getAllEventsByOrgId(@Param("id") Long id) {
        return eventDao.getEventByOrgId(id);
    }
    @Override
    public Page<EventModel> findAllEventsByOrgIdAndName(Long id, String search, Pageable pageable) {
        return eventRepository.findAllEventsByOrgIdAndName(id, search, pageable);
    }

    @Override
    public Page<EventModel> findAllEventsByOrgIdWithPagination(Long id, Pageable pageable) {
        return eventRepository.findAllEventsByOrgIdwithPagination(id, pageable);
    }


}
