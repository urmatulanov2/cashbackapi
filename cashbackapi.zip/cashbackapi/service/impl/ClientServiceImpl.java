package kg.nurtelecom.cashbackapi.service.impl;

import kg.nurtelecom.cashbackapi.dao.ClientDao;
import kg.nurtelecom.cashbackapi.entity.Client;
import kg.nurtelecom.cashbackapi.model.ClientLongModel;
import kg.nurtelecom.cashbackapi.model.ClientPersonalCodeModel;
import kg.nurtelecom.cashbackapi.model.ClientPreferenceModel;
import kg.nurtelecom.cashbackapi.model.ClientShortModel;
import kg.nurtelecom.cashbackapi.repository.ClientRepository;
import kg.nurtelecom.cashbackapi.service.ClientPreferenceValueService;
import kg.nurtelecom.cashbackapi.service.ClientService;
import kg.nurtelecom.cashbackapi.utils.RecordNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Date;
import java.util.List;

@Service
public class ClientServiceImpl implements ClientService {
    @Autowired
    private ClientRepository clientRepository;
    @Autowired
    private ClientPreferenceValueService clientPreferenceValueService;
    @Autowired
    private ClientDao clientDao;

    public Client findById(Long id) {
        return clientRepository.findById(id).orElseThrow(() ->
                new RecordNotFoundException("Record not found with id:" + id));
    }

    public List<Client> findAll() {
        return clientRepository.findAll();
    }

    public Page<ClientShortModel> getAllClientByPagination(Pageable pageable) {
        return clientRepository.getClientsByPagination(pageable);
    }

    public List<ClientShortModel> getAllClientByOrgId(Long id, String search) {
        return clientDao.getClientsByOrgId(id, search);
    }

    public Client create(Client client) {
        return clientRepository.save(client);
    }

    public Client create(ClientLongModel clientLongModel) {
        Client client = new Client();
        client.setPersonalCode(clientLongModel.getPersonalCode());
        client.setFirstName(clientLongModel.getFirstName());
        client.setLastName(clientLongModel.getLastName());
        client.setPatronymic(clientLongModel.getPatronymic());
        client.setNationality(clientLongModel.getNationality());
        client.setCreatedDate(Date.from(Instant.now()));
        client.setLocale(client.getLocale());
        client.setClientSex(client.getClientSex());
        return clientRepository.save(client);
    }

    public String deleteById(Long id) {
        clientRepository.deleteById(id);
        return "Client number " + id + " has been deleted!";
    }

    public Client putById(Long id, ClientLongModel client) {
        return clientRepository.findById(id)
                .map(newClient -> {
                    newClient.setClientSex(client.getClientSex());
                    newClient.setFirstName(client.getFirstName());
                    newClient.setLastName(client.getLastName());
                    newClient.setLocale(client.getLocale());
                    newClient.setNationality(client.getNationality());
                    newClient.setPatronymic(client.getPatronymic());
                    newClient.setPersonalCode(client.getPersonalCode());
                    newClient.setCreatedDate(clientRepository.findClientById(id).getCreatedDate());
                    return clientRepository.save(newClient);
                })
                .orElseThrow(() ->
                        new RecordNotFoundException("Record not found with id:" + id));
    }

    public ClientLongModel findModelById(Long id) {
        return clientRepository.findClientById(id);
    }

    public ClientPersonalCodeModel findCodeByClientId(Long id) {
        return clientDao.getCodeByClientId(id);
    }

    @Override
    public ClientLongModel findClientByPersonalCode(String code) {
        return clientRepository.findClientByPersonalCode(code);
    }

    public List<ClientPreferenceModel> getClientPreferences(Long clientId){
        return clientPreferenceValueService.getClientPreference(clientId);
    }

    public Page<ClientShortModel> findAllByNameOrDescription(String search, Pageable pageable) {
        return clientRepository.getClientsByName(search,pageable);
    }

}