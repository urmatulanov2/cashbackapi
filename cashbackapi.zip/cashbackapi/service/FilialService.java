package kg.nurtelecom.cashbackapi.service;

import kg.nurtelecom.cashbackapi.entity.Filial;
import kg.nurtelecom.cashbackapi.model.FilialModel;
import kg.nurtelecom.cashbackapi.model.FilialShortModel;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface FilialService {
    Filial findById(Long id);

    List<Filial> findAll();

    List<FilialModel> findAllByOrgId(Long id);

    Page<FilialModel> findAllByOrgIdWithPagination(Long id, Pageable pageable);

    Page<FilialModel> findAllByOrgIdAndByNameOrDescription(Long id, String search, Pageable pageable);

    Filial create(FilialModel filial);

    String deleteById(Long id);

    Filial putById(Long id, FilialModel filial);

//    List<FilialModel> findAllFilialsByOrgId(@Param("id") Long id);

    List<FilialShortModel> getAllFilialsByOrgId(@Param("id") Long id);
}