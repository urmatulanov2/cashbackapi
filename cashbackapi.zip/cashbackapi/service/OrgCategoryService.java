package kg.nurtelecom.cashbackapi.service;

import kg.nurtelecom.cashbackapi.entity.OrgCategory;
import kg.nurtelecom.cashbackapi.entity.OrgCategoryTag;
import kg.nurtelecom.cashbackapi.model.OrgCategoryModel;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface OrgCategoryService {
    OrgCategory findById(Long id);

    List<OrgCategory> findAll();

    Page<OrgCategoryModel> findAll(Pageable pageable);

    //    OrgCategory create(OrgCategory orgCategory);
    OrgCategory create(OrgCategoryModel orgCategoryModel);

    String deleteById(Long id);

//    OrgCategory putById(Long id, OrgCategory orgCategory);

    OrgCategory putById(Long id, OrgCategoryModel orgCategoryModel);

    OrgCategoryModel findOrgCategoryById(Long id);

    List<OrgCategoryModel> listAll();

    void addTag(Long catId, OrgCategoryTag tag);
}
