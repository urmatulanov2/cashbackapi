package kg.nurtelecom.cashbackapi.apicontroller;

import kg.nurtelecom.cashbackapi.entity.Balance;
import kg.nurtelecom.cashbackapi.service.BalanceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/balance")
public class BalanceRestController {
    @Autowired
    private BalanceService balanceService;

    @GetMapping("/{id}")
    public Balance getBalanceById(@PathVariable("id") Long id) {
        return balanceService.findById(id);
    }

    @GetMapping("/all")
    public List<Balance> getAll() {
        return balanceService.findAll();
    }

    @PutMapping("/{id}")
    public Balance putBalance(@PathVariable("id") Long id, @RequestBody Balance balance) {
        return balanceService.putById(id, balance);
    }

    @PostMapping()
    public Balance postBalance(@RequestBody Balance balance) {
        balanceService.create(balance);
        return balance;
    }

    @DeleteMapping("/{id}")
    public String deleteById(@PathVariable("id") Long id) {
        return balanceService.deleteById(id);
    }

}
