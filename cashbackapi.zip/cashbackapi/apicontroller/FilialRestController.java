package kg.nurtelecom.cashbackapi.apicontroller;

import kg.nurtelecom.cashbackapi.entity.Filial;
import kg.nurtelecom.cashbackapi.model.FilialModel;
import kg.nurtelecom.cashbackapi.model.FilialShortModel;
import kg.nurtelecom.cashbackapi.service.FilialService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/filial")
public class FilialRestController {
    @Autowired
    private FilialService filialService;

    @GetMapping("/{id}")
    public Filial getFilialById(@PathVariable("id") Long id) {
        return filialService.findById(id);
    }

    @PutMapping("/{id}")
    public Filial putFilial(@PathVariable("id") Long id, @RequestBody FilialModel filial) {
        return filialService.putById(id, filial);
    }

    @PostMapping()
    public Filial postFilial(@RequestBody FilialModel filial) {
        return filialService.create(filial);
    }

    @DeleteMapping("/{id}")
    public String deleteById(@PathVariable("id") Long id) {
        return filialService.deleteById(id);
    }

    @GetMapping("/allByOrgId/{id}")
    public List<FilialShortModel> findAllFilialsByOrgId(@PathVariable("id") Long id) {
        return filialService.getAllFilialsByOrgId(id);
    }

    @GetMapping("/all")
    public List<FilialModel> findAllByOrgId(@Param("id") Long id) {
        return filialService.findAllByOrgId(id);
    }

}
