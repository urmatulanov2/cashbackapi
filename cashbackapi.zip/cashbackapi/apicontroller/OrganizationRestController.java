package kg.nurtelecom.cashbackapi.apicontroller;

import kg.nurtelecom.cashbackapi.entity.Organization;
import kg.nurtelecom.cashbackapi.model.OrganizationFullModel;
import kg.nurtelecom.cashbackapi.model.OrganizationModel;
import kg.nurtelecom.cashbackapi.model.OrganizationModelImage;
import kg.nurtelecom.cashbackapi.service.OrganizationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/organization")
public class OrganizationRestController {
    @Autowired
    private OrganizationService organizationService;
    @Autowired
    private FilialRestController filialRestController;
    @Autowired
    private OrgBonusRestController orgBonusRestController;
    @Autowired
    private EventRestController eventRestController;

    @GetMapping("/list/{id}")
    public List<OrganizationModel> getAllOrganizationByUserId(@PathVariable("id") Long id) {
        return organizationService.getOrganizationListByClientId(id);
    }

    @GetMapping("/{id}")
    public Organization getOrganizationById(@PathVariable("id") Long id) {
        return organizationService.findById(id);
    }

    @GetMapping("/info/{id}")
    public OrganizationFullModel getOrganizationInfoById(@PathVariable("id") Long id) {
        return new OrganizationFullModel(organizationService.getOrganizationById(id), orgBonusRestController.findAllOrgBonusList(id),eventRestController.findAllEventsByOrgId(id), filialRestController.findAllFilialsByOrgId(id));
    }


    @GetMapping("/all")
    public List<Organization> getAll() {
        return organizationService.findAll();
    }

    @PutMapping("/{id}")
    public Organization putOrganization(@PathVariable("id") Long id, @RequestBody OrganizationModelImage organization) {
        return organizationService.putById(id, organization);
    }

    @PostMapping()
    public Organization postOrganization(@RequestBody OrganizationModelImage organization) {
        return organizationService.create(organization);
    }

    @DeleteMapping("/{id}")
    public String deleteById(@PathVariable("id") Long id) {
        return organizationService.deleteById(id);
    }

    @GetMapping("/list")
    public List<OrganizationModel> getAllOrgs() {
        return organizationService.findAllOrganizationList();
    }
}
