package kg.nurtelecom.cashbackapi.enums;

public enum BonusType {
    VALUE,
    LIST_TYPE
}
