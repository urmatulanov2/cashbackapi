package kg.nurtelecom.cashbackapi.enums;

public enum ClientLocale {
    EN, RU, KG;
}
