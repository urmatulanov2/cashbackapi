package kg.nurtelecom.cashbackapi.enums;

public enum Status {
    ACTIVE, NOT_ACTIVE, DELETED
}
