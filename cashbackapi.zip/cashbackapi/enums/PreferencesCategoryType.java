package kg.nurtelecom.cashbackapi.enums;

public enum PreferencesCategoryType {
    NUMBER,
    TEXT,
    CHECKBOX
}
