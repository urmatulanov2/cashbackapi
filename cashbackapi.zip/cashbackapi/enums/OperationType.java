package kg.nurtelecom.cashbackapi.enums;

public enum OperationType {
    CREDIT, DEBIT;
}
