package kg.nurtelecom.cashbackapi.enums;

public enum ClientSex {
    MALE, FEMALE;
}
