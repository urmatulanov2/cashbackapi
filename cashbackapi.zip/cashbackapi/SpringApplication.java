package kg.nurtelecom.cashbackapi;

public class SpringApplication {
    public static void run(Class<CashbackapiApplication> cashbackapiApplicationClass, String[] args) {
    }
}
