package kg.nurtelecom.cashbackapi.dao;

import kg.nurtelecom.cashbackapi.model.HistoryModel;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@Repository
public class BalanceDao {
    @Value("${spring.datasource.driver-class-name}")
    private String JDBC_DRIVER;
    @Value("${spring.datasource.jdbc-url}")
    private String DB_URL;
    @Value("${spring.datasource.username}")
    private String USER;
    @Value("${spring.datasource.password}")
    private String PASS;

    public List<HistoryModel> getBalanceHistoryByClientId(Long clientId){
        List<HistoryModel> result = new ArrayList<>();
        Connection connection = null;
        Statement stmt = null;
        try {
            Class.forName(JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, USER, PASS);
            stmt = connection.createStatement();

            String query = "SELECT balance.client_id, history.created_date, history.operation_type, history.amount, balance.amount AS total, type.name AS bonus_type, org.name " +
                    "FROM balance_history history " +
                    "JOIN balance balance ON balance.id = history.balance_id " +
                    "JOIN org_bonus bonus ON bonus.id = balance.org_bonus_id " +
                    "JOIN org_bonus_type type ON type.id = bonus.org_bonus_type_id " +
                    "JOIN organization org ON org.id = bonus.organization_id WHERE balance.client_id = " + clientId;

            ResultSet resultSet = stmt.executeQuery(query);

            while (resultSet.next()) {
                HistoryModel dto = new HistoryModel();
                dto.setClientId(resultSet.getLong("client_id"));
                dto.setCreatedDate(resultSet.getDate("created_date"));
                dto.setOperationType(resultSet.getString("operation_type"));
                dto.setBonusType(resultSet.getString("bonus_type"));
                dto.setAmount(resultSet.getDouble("amount"));
                dto.setTotal(resultSet.getDouble("total"));
                dto.setOrganizationName(resultSet.getString("name"));
                result.add(dto);
            }

        } catch (Exception se) {
            se.printStackTrace();
        } finally {
            try {
                if (stmt != null)
                    connection.close();
            } catch (SQLException se) {
            }
            try {
                if (connection != null)
                    connection.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        return result;
    }

    public List<HistoryModel> getBalanceHistoryByClientIdAndOrgIdAndBonusTypeId(Long clientId, Long orgId, Long typeId){
        List<HistoryModel> result = new ArrayList<>();
        Connection connection = null;
        Statement stmt = null;
        try {
            Class.forName(JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, USER, PASS);
            stmt = connection.createStatement();

            String query = "SELECT balance.client_id, history.created_date, history.operation_type, history.amount, balance.amount AS total, type.name AS bonus_type, org.name " +
                    "FROM balance_history history " +
                    "JOIN balance balance ON balance.id = history.balance_id " +
                    "JOIN org_bonus bonus ON bonus.id = balance.org_bonus_id " +
                    "JOIN org_bonus_type type ON type.id = bonus.org_bonus_type_id " +
                    "JOIN organization org ON org.id = bonus.organization_id WHERE balance.client_id = " + clientId;

            if (orgId != null){
                query = query + " and org.id=" + orgId;
            }
            if(typeId != null){
                query = query + " and bonus.org_bonus_type_id=" + typeId;
            }

            ResultSet resultSet = stmt.executeQuery(query);

            while (resultSet.next()) {
                HistoryModel dto = new HistoryModel();
                dto.setClientId(resultSet.getLong("client_id"));
                dto.setCreatedDate(resultSet.getDate("created_date"));
                dto.setOperationType(resultSet.getString("operation_type"));
                dto.setBonusType(resultSet.getString("bonus_type"));
                dto.setAmount(resultSet.getDouble("amount"));
                dto.setTotal(resultSet.getDouble("total"));
                dto.setOrganizationName(resultSet.getString("name"));
                result.add(dto);
            }

        } catch (Exception se) {
            se.printStackTrace();
        } finally {
            try {
                if (stmt != null)
                    connection.close();
            } catch (SQLException se) {
            }
            try {
                if (connection != null)
                    connection.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        return result;
    }
    public List<HistoryModel> getBalanceByClientIdAndOrgIdAndBonusTypeId(Long clientId, Long orgId, Long typeId){
        List<HistoryModel> result = new ArrayList<>();
        Connection connection = null;
        Statement stmt = null;
        try {
            Class.forName(JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, USER, PASS);
            stmt = connection.createStatement();

            String query = "SELECT balance.amount AS total, type.name AS bonus_type, org.name " +
                    "FROM " +
                    "balance balance " +
                    "JOIN org_bonus bonus ON bonus.id = balance.org_bonus_id " +
                    "JOIN org_bonus_type type ON type.id = bonus.org_bonus_type_id " +
                    "JOIN organization org ON org.id = bonus.organization_id WHERE balance.client_id = " + clientId;

            if (orgId != null){
                query = query + " and org.id=" + orgId;
            }
            if(typeId != null){
                query = query + " and bonus.org_bonus_type_id=" + typeId;
            }

            ResultSet resultSet = stmt.executeQuery(query);

            while (resultSet.next()) {
                HistoryModel dto = new HistoryModel();
                dto.setBonusType(resultSet.getString("bonus_type"));
                dto.setTotal(resultSet.getDouble("total"));
                dto.setOrganizationName(resultSet.getString("name"));
                result.add(dto);
            }

        } catch (Exception se) {
            se.printStackTrace();
        } finally {
            try {
                if (stmt != null)
                    connection.close();
            } catch (SQLException se) {
            }
            try {
                if (connection != null)
                    connection.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        return result;
    }
}
