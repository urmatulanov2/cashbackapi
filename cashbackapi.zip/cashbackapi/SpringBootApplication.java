package kg.nurtelecom.cashbackapi;

public @interface SpringBootApplication {
}
