package kg.nurtelecom.cashbackapi.controller;

import kg.nurtelecom.cashbackapi.model.ClientLongModel;
import kg.nurtelecom.cashbackapi.service.ClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@RequestMapping("/cashier/{id}")
@Controller
public class CashierController {
    @Autowired
    ClientService clientService;

    @GetMapping
    public String operationPage(Model model){

        return "cashierOperation";
    }


    @GetMapping("/getClient/{code}")
    public String getClientByCode(@PathVariable("code")String code, Model model){
        ClientLongModel client = clientService.findClientByPersonalCode(code);
        System.out.println(client);
        model.addAttribute("client",client);
        return "cashierOperation :: resultList";
    }


}
