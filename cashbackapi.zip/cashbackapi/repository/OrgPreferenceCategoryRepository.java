package kg.nurtelecom.cashbackapi.repository;

import kg.nurtelecom.cashbackapi.entity.OrgPreferenceCategory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrgPreferenceCategoryRepository extends JpaRepository<OrgPreferenceCategory, Long> {
}
